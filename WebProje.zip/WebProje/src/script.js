function validation(){
	var name= document.getElementById("name").value;
	var subject= document.getElementById("subject").value;
	var phone= document.getElementById("phone").value;
	var email= document.getElementById("email").value;
	var message= document.getElementById("message").value;
	var error_message= document.getElementById("error_message");
    var text;

	error_message.style.padding="10px";

if(name.length <5){
		text  = "Gecerli bir isim gir(5 karakterden fazla olmalıdır)";
		error_message.innerHTML = text;
		return false;
	}

if(subject.length <10){
		text  = "Konu 10 karakterden fazla olmalı";
		error_message.innerHTML = text;
		return false;
	}

if(isNaN(phone) || phone.length !=10){
	text="Telefon numarası 0  olmadan 10 adet sayı içermeli";
	error_message.innerHTML=text;
	return  false;
}

if(email.indexOf("@") == -1 || email.length < 6 ){
		text  = "Mail @ olmalı ve 6 karakterden fazla olmalıdır";
		error_message.innerHTML = text;
		return false;
	}


if(message.length <=30){
		text  = "Mesajın 30 karakterden fazla olmalı";
		error_message.innerHTML = text;
		return false;
	}

	alert("mesajın bize iletildi ..")
	return true;

}